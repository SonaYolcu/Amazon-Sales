## Import Libraries


```python
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
from textblob import TextBlob
```


```python
print(matplotlib.__version__)
```

    3.7.2
    

## Data Loading and Exploration | Cleaning


```python
#Load a CSV file then creating a dataframe
amazon = pd.read_csv(r"C:\Users\sonay\Downloads\amazon.csv")
amazon
```


```python
#have a look on the columns and their data types using detailed info function
amazon.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1465 entries, 0 to 1464
    Data columns (total 16 columns):
     #   Column               Non-Null Count  Dtype 
    ---  ------               --------------  ----- 
     0   product_id           1465 non-null   object
     1   product_name         1465 non-null   object
     2   category             1465 non-null   object
     3   discounted_price     1465 non-null   object
     4   actual_price         1465 non-null   object
     5   discount_percentage  1465 non-null   object
     6   rating               1465 non-null   object
     7   rating_count         1463 non-null   object
     8   about_product        1465 non-null   object
     9   user_id              1465 non-null   object
     10  user_name            1465 non-null   object
     11  review_id            1465 non-null   object
     12  review_title         1465 non-null   object
     13  review_content       1465 non-null   object
     14  img_link             1465 non-null   object
     15  product_link         1465 non-null   object
    dtypes: object(16)
    memory usage: 183.3+ KB
    


```python
#column names
amazon.columns
```




    Index(['product_id', 'product_name', 'category', 'discounted_price',
           'actual_price', 'discount_percentage', 'rating', 'rating_count',
           'about_product', 'user_id', 'user_name', 'review_id', 'review_title',
           'review_content', 'img_link', 'product_link', 'comment',
           'comment_copy'],
          dtype='object')



##  Missing Values


```python
#Finding the missing values in each columns
amazon.isnull().sum()
```




    product_id             0
    product_name           0
    category               0
    discounted_price       0
    actual_price           0
    discount_percentage    0
    rating                 0
    rating_count           2
    about_product          0
    user_id                0
    user_name              0
    review_id              0
    review_title           0
    review_content         0
    img_link               0
    product_link           0
    dtype: int64




```python
#Finding columns, where missing values
amazon[amazon.isnull().sum(axis=1)>0]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_name</th>
      <th>category</th>
      <th>discounted_price</th>
      <th>actual_price</th>
      <th>discount_percentage</th>
      <th>rating</th>
      <th>rating_count</th>
      <th>about_product</th>
      <th>user_id</th>
      <th>user_name</th>
      <th>review_id</th>
      <th>review_title</th>
      <th>review_content</th>
      <th>img_link</th>
      <th>product_link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>282</th>
      <td>B0B94JPY2N</td>
      <td>Amazon Brand - Solimo 65W Fast Charging Braide...</td>
      <td>Computers&amp;Accessories|Accessories&amp;Peripherals|...</td>
      <td>₹199</td>
      <td>₹999</td>
      <td>80%</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>USB C to C Cable: This cable has type C connec...</td>
      <td>AE7CFHY23VAJT2FI4NZKKP6GS2UQ</td>
      <td>Pranav</td>
      <td>RUB7U91HVZ30</td>
      <td>The cable works but is not 65W as advertised</td>
      <td>I have a pd supported car charger and I bought...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Amazon-Brand-Charging-Su...</td>
    </tr>
    <tr>
      <th>324</th>
      <td>B0BQRJ3C47</td>
      <td>REDTECH USB-C to Lightning Cable 3.3FT, [Apple...</td>
      <td>Computers&amp;Accessories|Accessories&amp;Peripherals|...</td>
      <td>₹249</td>
      <td>₹999</td>
      <td>75%</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>💎[The Fastest Charge] - This iPhone USB C cabl...</td>
      <td>AGJC5O5H5BBXWUV7WRIEIOOR3TVQ</td>
      <td>Abdul Gafur</td>
      <td>RQXD5SAMMPC6L</td>
      <td>Awesome Product</td>
      <td>Quick delivery.Awesome ProductPacking was good...</td>
      <td>https://m.media-amazon.com/images/I/31-q0xhaTA...</td>
      <td>https://www.amazon.in/REDTECH-Lightning-Certif...</td>
    </tr>
  </tbody>
</table>
</div>




```python
#clear columns from null values
amazon.dropna(inplace=True)
```


```python
#Cheking missing values
amazon.isna().sum()
```




    product_id             0
    product_name           0
    category               0
    discounted_price       0
    actual_price           0
    discount_percentage    0
    rating                 0
    rating_count           0
    about_product          0
    user_id                0
    user_name              0
    review_id              0
    review_title           0
    review_content         0
    img_link               0
    product_link           0
    dtype: int64




```python
# Finding unusual string in rating column
amazon['rating'].value_counts()
```




    rating
    4.1    244
    4.3    230
    4.2    228
    4.0    129
    3.9    123
    4.4    123
    3.8     86
    4.5     75
    4       52
    3.7     42
    3.6     35
    3.5     26
    4.6     17
    3.3     16
    3.4     10
    4.7      6
    3.1      4
    4.8      3
    3.2      2
    2.8      2
    3.0      2
    5.0      2
    2.3      1
    |        1
    2        1
    3        1
    2.6      1
    2.9      1
    Name: count, dtype: int64



##  Changing Data Types of Columns from object to float


```python

amazon = amazon[amazon['rating']!="|"]
amazon['rating'] = amazon['rating'].astype('float64')
amazon.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 1462 entries, 0 to 1464
    Data columns (total 16 columns):
     #   Column               Non-Null Count  Dtype  
    ---  ------               --------------  -----  
     0   product_id           1462 non-null   object 
     1   product_name         1462 non-null   object 
     2   category             1462 non-null   object 
     3   discounted_price     1462 non-null   object 
     4   actual_price         1462 non-null   object 
     5   discount_percentage  1462 non-null   object 
     6   rating               1462 non-null   float64
     7   rating_count         1462 non-null   object 
     8   about_product        1462 non-null   object 
     9   user_id              1462 non-null   object 
     10  user_name            1462 non-null   object 
     11  review_id            1462 non-null   object 
     12  review_title         1462 non-null   object 
     13  review_content       1462 non-null   object 
     14  img_link             1462 non-null   object 
     15  product_link         1462 non-null   object 
    dtypes: float64(1), object(15)
    memory usage: 194.2+ KB
    

    C:\Users\sonay\AppData\Local\Temp\ipykernel_22444\959781986.py:2: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      amazon['rating'] = amazon['rating'].astype('float64')
    


```python
amazon['rating'].dtype
```




    dtype('float64')




```python
#Creating a function that replaces "," with an empty line
def f(x):
    if isinstance(x, str):
        x =  x.replace(',', '')
    return x
 


amazon['rating_count'] = amazon['rating_count'].apply(f)
amazon['rating_count'] = amazon['rating_count'].astype('float64')

amazon.head(3)
```

    C:\Users\sonay\AppData\Local\Temp\ipykernel_22444\153722380.py:8: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      amazon['rating_count'] = amazon['rating_count'].apply(f)
    C:\Users\sonay\AppData\Local\Temp\ipykernel_22444\153722380.py:9: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      amazon['rating_count'] = amazon['rating_count'].astype('float64')
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_name</th>
      <th>category</th>
      <th>discounted_price</th>
      <th>actual_price</th>
      <th>discount_percentage</th>
      <th>rating</th>
      <th>rating_count</th>
      <th>about_product</th>
      <th>user_id</th>
      <th>user_name</th>
      <th>review_id</th>
      <th>review_title</th>
      <th>review_content</th>
      <th>img_link</th>
      <th>product_link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B07JW9H4J1</td>
      <td>Wayona Nylon Braided USB to Lightning Fast Cha...</td>
      <td>Computers&amp;Accessories|Accessories&amp;Peripherals|...</td>
      <td>₹399</td>
      <td>₹1,099</td>
      <td>64%</td>
      <td>4.2</td>
      <td>24269.0</td>
      <td>High Compatibility : Compatible With iPhone 12...</td>
      <td>AG3D6O4STAQKAY2UVGEUV46KN35Q,AHMY5CWJMMK5BJRBB...</td>
      <td>Manav,Adarsh gupta,Sundeep,S.Sayeed Ahmed,jasp...</td>
      <td>R3HXWT0LRP0NMF,R2AJM3LFTLZHFO,R6AQJGUP6P86,R1K...</td>
      <td>Satisfied,Charging is really fast,Value for mo...</td>
      <td>Looks durable Charging is fine tooNo complains...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Wayona-Braided-WN3LG1-Sy...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B098NS6PVG</td>
      <td>Ambrane Unbreakable 60W / 3A Fast Charging 1.5...</td>
      <td>Computers&amp;Accessories|Accessories&amp;Peripherals|...</td>
      <td>₹199</td>
      <td>₹349</td>
      <td>43%</td>
      <td>4.0</td>
      <td>43994.0</td>
      <td>Compatible with all Type C enabled devices, be...</td>
      <td>AECPFYFQVRUWC3KGNLJIOREFP5LQ,AGYYVPDD7YG7FYNBX...</td>
      <td>ArdKn,Nirbhay kumar,Sagar Viswanathan,Asp,Plac...</td>
      <td>RGIQEG07R9HS2,R1SMWZQ86XIN8U,R2J3Y1WL29GWDE,RY...</td>
      <td>A Good Braided Cable for Your Type C Device,Go...</td>
      <td>I ordered this cable to connect my phone to An...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Ambrane-Unbreakable-Char...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B096MSW6CT</td>
      <td>Sounce Fast Phone Charging Cable &amp; Data Sync U...</td>
      <td>Computers&amp;Accessories|Accessories&amp;Peripherals|...</td>
      <td>₹199</td>
      <td>₹1,899</td>
      <td>90%</td>
      <td>3.9</td>
      <td>7928.0</td>
      <td>【 Fast Charger&amp; Data Sync】-With built-in safet...</td>
      <td>AGU3BBQ2V2DDAMOAKGFAWDDQ6QHA,AESFLDV2PT363T2AQ...</td>
      <td>Kunal,Himanshu,viswanath,sai niharka,saqib mal...</td>
      <td>R3J3EQQ9TZI5ZJ,R3E7WBGK7ID0KV,RWU79XKQ6I1QF,R2...</td>
      <td>Good speed for earlier versions,Good Product,W...</td>
      <td>Not quite durable and sturdy,https://m.media-a...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Sounce-iPhone-Charging-C...</td>
    </tr>
  </tbody>
</table>
</div>




```python
amazon['rating_count'].dtype
```




    dtype('float64')




```python
#Creating and implementing functions for shortening names from 'category' column
def short_name(name):
    name = name.split('|')
    return name[0] + '|' + name[-1]
amazon['category'] = amazon['category'].apply(short_name)


#Creating and accepting functions for converting value for columns 'discounted_price', 'actual_price'
def f1(x):
    if isinstance(x, str):
        x =  x.replace('₹', '').replace(',', '')
    return x
amazon[['discounted_price', 'actual_price']] = amazon[['discounted_price', 'actual_price']].applymap(f1)
amazon = amazon.astype({'discounted_price':'float64', 'actual_price': 'float64'})

#Converting the value of the 'discount_percentage' column
amazon['discount_percentage'] = amazon['discount_percentage'].apply(lambda x: float(x.replace('%', '')))

amazon.head(3)
```

    C:\Users\sonay\AppData\Local\Temp\ipykernel_22444\3706718397.py:5: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      amazon['category'] = amazon['category'].apply(short_name)
    C:\Users\sonay\AppData\Local\Temp\ipykernel_22444\3706718397.py:13: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      amazon[['discounted_price', 'actual_price']] = amazon[['discounted_price', 'actual_price']].applymap(f1)
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_name</th>
      <th>category</th>
      <th>discounted_price</th>
      <th>actual_price</th>
      <th>discount_percentage</th>
      <th>rating</th>
      <th>rating_count</th>
      <th>about_product</th>
      <th>user_id</th>
      <th>user_name</th>
      <th>review_id</th>
      <th>review_title</th>
      <th>review_content</th>
      <th>img_link</th>
      <th>product_link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B07JW9H4J1</td>
      <td>Wayona Nylon Braided USB to Lightning Fast Cha...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>399.0</td>
      <td>1099.0</td>
      <td>64.0</td>
      <td>4.2</td>
      <td>24269.0</td>
      <td>High Compatibility : Compatible With iPhone 12...</td>
      <td>AG3D6O4STAQKAY2UVGEUV46KN35Q,AHMY5CWJMMK5BJRBB...</td>
      <td>Manav,Adarsh gupta,Sundeep,S.Sayeed Ahmed,jasp...</td>
      <td>R3HXWT0LRP0NMF,R2AJM3LFTLZHFO,R6AQJGUP6P86,R1K...</td>
      <td>Satisfied,Charging is really fast,Value for mo...</td>
      <td>Looks durable Charging is fine tooNo complains...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Wayona-Braided-WN3LG1-Sy...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B098NS6PVG</td>
      <td>Ambrane Unbreakable 60W / 3A Fast Charging 1.5...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>199.0</td>
      <td>349.0</td>
      <td>43.0</td>
      <td>4.0</td>
      <td>43994.0</td>
      <td>Compatible with all Type C enabled devices, be...</td>
      <td>AECPFYFQVRUWC3KGNLJIOREFP5LQ,AGYYVPDD7YG7FYNBX...</td>
      <td>ArdKn,Nirbhay kumar,Sagar Viswanathan,Asp,Plac...</td>
      <td>RGIQEG07R9HS2,R1SMWZQ86XIN8U,R2J3Y1WL29GWDE,RY...</td>
      <td>A Good Braided Cable for Your Type C Device,Go...</td>
      <td>I ordered this cable to connect my phone to An...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Ambrane-Unbreakable-Char...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B096MSW6CT</td>
      <td>Sounce Fast Phone Charging Cable &amp; Data Sync U...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>199.0</td>
      <td>1899.0</td>
      <td>90.0</td>
      <td>3.9</td>
      <td>7928.0</td>
      <td>【 Fast Charger&amp; Data Sync】-With built-in safet...</td>
      <td>AGU3BBQ2V2DDAMOAKGFAWDDQ6QHA,AESFLDV2PT363T2AQ...</td>
      <td>Kunal,Himanshu,viswanath,sai niharka,saqib mal...</td>
      <td>R3J3EQQ9TZI5ZJ,R3E7WBGK7ID0KV,RWU79XKQ6I1QF,R2...</td>
      <td>Good speed for earlier versions,Good Product,W...</td>
      <td>Not quite durable and sturdy,https://m.media-a...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Sounce-iPhone-Charging-C...</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Checking data types
amazon['discount_percentage'].dtype
```




    dtype('float64')




```python
#Creating a function using a TextBlob object that checks the tone of the reviews
def analiz_text(text):
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    
    if polarity > 0:
        return 'Positive'
    elif polarity < 0:
        return 'Negative'
    else:
        return 'Neytral'
    
amazon['comment'] = amazon['review_title'].apply(analiz_text)
amazon['comment_copy'] = amazon['comment']
amazon.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_id</th>
      <th>product_name</th>
      <th>category</th>
      <th>discounted_price</th>
      <th>actual_price</th>
      <th>discount_percentage</th>
      <th>rating</th>
      <th>rating_count</th>
      <th>about_product</th>
      <th>user_id</th>
      <th>user_name</th>
      <th>review_id</th>
      <th>review_title</th>
      <th>review_content</th>
      <th>img_link</th>
      <th>product_link</th>
      <th>comment</th>
      <th>comment_copy</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>B07JW9H4J1</td>
      <td>Wayona Nylon Braided USB to Lightning Fast Cha...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>399.0</td>
      <td>1099.0</td>
      <td>64.0</td>
      <td>4.2</td>
      <td>24269.0</td>
      <td>High Compatibility : Compatible With iPhone 12...</td>
      <td>AG3D6O4STAQKAY2UVGEUV46KN35Q,AHMY5CWJMMK5BJRBB...</td>
      <td>Manav,Adarsh gupta,Sundeep,S.Sayeed Ahmed,jasp...</td>
      <td>R3HXWT0LRP0NMF,R2AJM3LFTLZHFO,R6AQJGUP6P86,R1K...</td>
      <td>Satisfied,Charging is really fast,Value for mo...</td>
      <td>Looks durable Charging is fine tooNo complains...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Wayona-Braided-WN3LG1-Sy...</td>
      <td>Positive</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>1</th>
      <td>B098NS6PVG</td>
      <td>Ambrane Unbreakable 60W / 3A Fast Charging 1.5...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>199.0</td>
      <td>349.0</td>
      <td>43.0</td>
      <td>4.0</td>
      <td>43994.0</td>
      <td>Compatible with all Type C enabled devices, be...</td>
      <td>AECPFYFQVRUWC3KGNLJIOREFP5LQ,AGYYVPDD7YG7FYNBX...</td>
      <td>ArdKn,Nirbhay kumar,Sagar Viswanathan,Asp,Plac...</td>
      <td>RGIQEG07R9HS2,R1SMWZQ86XIN8U,R2J3Y1WL29GWDE,RY...</td>
      <td>A Good Braided Cable for Your Type C Device,Go...</td>
      <td>I ordered this cable to connect my phone to An...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Ambrane-Unbreakable-Char...</td>
      <td>Positive</td>
      <td>Positive</td>
    </tr>
    <tr>
      <th>2</th>
      <td>B096MSW6CT</td>
      <td>Sounce Fast Phone Charging Cable &amp; Data Sync U...</td>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>199.0</td>
      <td>1899.0</td>
      <td>90.0</td>
      <td>3.9</td>
      <td>7928.0</td>
      <td>【 Fast Charger&amp; Data Sync】-With built-in safet...</td>
      <td>AGU3BBQ2V2DDAMOAKGFAWDDQ6QHA,AESFLDV2PT363T2AQ...</td>
      <td>Kunal,Himanshu,viswanath,sai niharka,saqib mal...</td>
      <td>R3J3EQQ9TZI5ZJ,R3E7WBGK7ID0KV,RWU79XKQ6I1QF,R2...</td>
      <td>Good speed for earlier versions,Good Product,W...</td>
      <td>Not quite durable and sturdy,https://m.media-a...</td>
      <td>https://m.media-amazon.com/images/W/WEBP_40237...</td>
      <td>https://www.amazon.in/Sounce-iPhone-Charging-C...</td>
      <td>Positive</td>
      <td>Positive</td>
    </tr>
  </tbody>
</table>
</div>



## Duplicates


```python
amazon.duplicated().any()
```




    False



## Grouping and Aggregation


```python
a = amazon[['category', 'product_name']].groupby('category', sort=False).count()
a[a['product_name']<5]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product_name</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Electronics|RCACables</th>
      <td>2</td>
    </tr>
    <tr>
      <th>Electronics|Mounts</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Electronics|OpticalCables</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Electronics|Projectors</th>
      <td>3</td>
    </tr>
    <tr>
      <th>Electronics|Adapters</th>
      <td>3</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|RotiMakers</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|FanParts&amp;Accessories</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|StandMixers</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|PedestalFans</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|HandheldBags</th>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>142 rows × 1 columns</p>
</div>




```python
df_group_rating = amazon[['category', 'rating']].groupby('category').mean().sort_values(by='rating', ascending=False)

df_group_rating.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>rating</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Computers&amp;Accessories|Tablets</th>
      <td>4.6</td>
    </tr>
    <tr>
      <th>Computers&amp;Accessories|PowerLANAdapters</th>
      <td>4.5</td>
    </tr>
    <tr>
      <th>Electronics|StreamingClients</th>
      <td>4.5</td>
    </tr>
    <tr>
      <th>Computers&amp;Accessories|Memory</th>
      <td>4.5</td>
    </tr>
    <tr>
      <th>Home&amp;Kitchen|SmallApplianceParts&amp;Accessories</th>
      <td>4.5</td>
    </tr>
  </tbody>
</table>
</div>




```python
discount_rating = amazon[['category', 'discount_percentage']].groupby(['category']).mean().merge(merge_table, on='category', how='inner').sort_values(by='rating', ascending=False)
discount_rating.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>discount_percentage</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
      <th>rating</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Electronics|ScreenProtectors</th>
      <td>66.857143</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>4.471429</td>
    </tr>
    <tr>
      <th>Electronics|DisposableBatteries</th>
      <td>14.285714</td>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>4.414286</td>
    </tr>
    <tr>
      <th>Computers&amp;Accessories|ExternalHardDisks</th>
      <td>27.000000</td>
      <td>4</td>
      <td>2</td>
      <td>0</td>
      <td>4.400000</td>
    </tr>
    <tr>
      <th>Computers&amp;Accessories|GamingMice</th>
      <td>33.500000</td>
      <td>5</td>
      <td>1</td>
      <td>0</td>
      <td>4.383333</td>
    </tr>
    <tr>
      <th>Computers&amp;Accessories|MousePads</th>
      <td>61.250000</td>
      <td>8</td>
      <td>0</td>
      <td>0</td>
      <td>4.375000</td>
    </tr>
  </tbody>
</table>
</div>



## Creating a pivot table 


```python
#Creating a pivot table that summarizes the number of positive, negative, and neutral reviews by category
df_comment_percent = amazon.pivot_table(values='comment_copy', index='category', columns='comment', aggfunc='count', fill_value=0, sort=False)
df_comment_percent.sort_values(by='Positive', ascending=False, inplace=True)
df_comment_percent = df_comment_percent[df_comment_percent.sum(axis=1)>5]
df_comment_percent.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>comment</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Computers&amp;Accessories|USBCables</th>
      <td>192</td>
      <td>15</td>
      <td>24</td>
    </tr>
    <tr>
      <th>Electronics|SmartWatches</th>
      <td>63</td>
      <td>7</td>
      <td>6</td>
    </tr>
    <tr>
      <th>Electronics|SmartTelevisions</th>
      <td>56</td>
      <td>4</td>
      <td>3</td>
    </tr>
    <tr>
      <th>Electronics|Smartphones</th>
      <td>49</td>
      <td>15</td>
      <td>4</td>
    </tr>
    <tr>
      <th>Electronics|In-Ear</th>
      <td>46</td>
      <td>3</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Convert the number of comments to a percentage
df_comment_percent['comment_sum'] = df_comment_percent.iloc[:, 0:3].sum(axis=1)
df_comment_percent ['positive_comm_percent'] =round(df_comment_percent['Positive']*100/df_comment_percent['comment_sum'])
df_comment_percent ['negative_comm_percent'] = round(df_comment_percent['Negative']*100/df_comment_percent['comment_sum'])
df_comment_percent['neytral_com_percent'] = round(df_comment_percent['Neytral']*100/df_comment_percent['comment_sum'])
df_comment_percent.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>comment</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
      <th>comment_sum</th>
      <th>positive_comm_percent</th>
      <th>negative_comm_percent</th>
      <th>neytral_com_percent</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Computers&amp;Accessories|USBCables</th>
      <td>192</td>
      <td>15</td>
      <td>24</td>
      <td>231</td>
      <td>83.0</td>
      <td>6.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <th>Electronics|SmartWatches</th>
      <td>63</td>
      <td>7</td>
      <td>6</td>
      <td>76</td>
      <td>83.0</td>
      <td>9.0</td>
      <td>8.0</td>
    </tr>
    <tr>
      <th>Electronics|SmartTelevisions</th>
      <td>56</td>
      <td>4</td>
      <td>3</td>
      <td>63</td>
      <td>89.0</td>
      <td>6.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>Electronics|Smartphones</th>
      <td>49</td>
      <td>15</td>
      <td>4</td>
      <td>68</td>
      <td>72.0</td>
      <td>22.0</td>
      <td>6.0</td>
    </tr>
    <tr>
      <th>Electronics|In-Ear</th>
      <td>46</td>
      <td>3</td>
      <td>3</td>
      <td>52</td>
      <td>88.0</td>
      <td>6.0</td>
      <td>6.0</td>
    </tr>
  </tbody>
</table>
</div>



## Joining dataframes 


```python
#Joining two dataframes, that to compare columns 'rating' and 'positive_comment'
merge_table = df_comment_percent.merge(df_group_rating, how='inner', on='category')
merge_table.sort_values(by='Positive',ascending=False, inplace=True)
merge_table.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
      <th>comment_sum</th>
      <th>positive_comm_percent</th>
      <th>negative_comm_percent</th>
      <th>neytral_com_percent</th>
      <th>rating</th>
    </tr>
    <tr>
      <th>category</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Computers&amp;Accessories|USBCables</th>
      <td>192</td>
      <td>15</td>
      <td>24</td>
      <td>231</td>
      <td>83.0</td>
      <td>6.0</td>
      <td>10.0</td>
      <td>4.153247</td>
    </tr>
    <tr>
      <th>Electronics|SmartWatches</th>
      <td>63</td>
      <td>7</td>
      <td>6</td>
      <td>76</td>
      <td>83.0</td>
      <td>9.0</td>
      <td>8.0</td>
      <td>4.025000</td>
    </tr>
    <tr>
      <th>Electronics|SmartTelevisions</th>
      <td>56</td>
      <td>4</td>
      <td>3</td>
      <td>63</td>
      <td>89.0</td>
      <td>6.0</td>
      <td>5.0</td>
      <td>4.209524</td>
    </tr>
    <tr>
      <th>Electronics|Smartphones</th>
      <td>49</td>
      <td>15</td>
      <td>4</td>
      <td>68</td>
      <td>72.0</td>
      <td>22.0</td>
      <td>6.0</td>
      <td>4.100000</td>
    </tr>
    <tr>
      <th>Electronics|In-Ear</th>
      <td>46</td>
      <td>3</td>
      <td>3</td>
      <td>52</td>
      <td>88.0</td>
      <td>6.0</td>
      <td>6.0</td>
      <td>3.898077</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

# Data Visualization

## Histogram


```python
# Plot distribution of actual_price
plt.hist(amazon['actual_price'], color='c',alpha=0.7)
plt.xlabel('Actual Price')
plt.ylabel('Frequency')
plt.show()
```


    
![png](output_35_0.png)
    


## Bar


```python
# Creating a bar chart that shows the top 10 popular products
plt.figure(figsize=(16, 6))
plt.title('Top 10 products by category')

plt.bar(df_group_rating.iloc[0:10].index.values, df_group_rating['rating'].iloc[0:10] , color='c')
plt.grid(linestyle='--', axis='y',alpha=0.5)
plt.ylim(4, 5)
plt.yticks([4, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5])
plt.tick_params(axis='x', labelrotation=90)
plt.ylabel('Rating')
plt.show()
```


    
![png](output_37_0.png)
    


  ## Determining the factors influencing the rating


```python
# Создание график поквзывающий сравнения 'rating' и 'positive_comment'
merge_table[['Positive', 'Negative', 'Neytral']].iloc[0:10].plot(kind='bar',figsize=(16, 6), title='Top 10 Most Reviewed Products' ,ylabel='Count of comments', color=['darkcyan', 'darkred', 'olive'])
merge_table['rating'].iloc[0:10].plot(secondary_y=True,figsize=(16, 6), style='o--', title='Top 10 Most Reviewed Products', grid='horizontal',ylabel='Rating', color='lightcoral', alpha=0.7, rot=90)

```




    <Axes: ylabel='Rating'>




    
![png](output_39_1.png)
    



```python
merge_table.iloc[0:10].plot(kind='bar',figsize=(16, 6), y=['Positive', 'Negative', 'Neytral'], title='Top 10 Most Reviewed Products', grid='horizontal',ylabel='Count of comments', color=['darkcyan', 'darkred', 'olive'])

```




    <Axes: title={'center': 'Top 10 Most Reviewed Products'}, xlabel='category', ylabel='Count of comments'>




    
![png](output_40_1.png)
    



```python
#changing merge_table to dataframe with the new index
merge_table.reset_index(inplace=True)
merge_table.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>category</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
      <th>comment_sum</th>
      <th>positive_comm_percent</th>
      <th>negative_comm_percent</th>
      <th>neytral_com_percent</th>
      <th>rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Computers&amp;Accessories|USBCables</td>
      <td>192</td>
      <td>15</td>
      <td>24</td>
      <td>231</td>
      <td>83.0</td>
      <td>6.0</td>
      <td>10.0</td>
      <td>4.153247</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Electronics|SmartWatches</td>
      <td>63</td>
      <td>7</td>
      <td>6</td>
      <td>76</td>
      <td>83.0</td>
      <td>9.0</td>
      <td>8.0</td>
      <td>4.025000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Electronics|SmartTelevisions</td>
      <td>56</td>
      <td>4</td>
      <td>3</td>
      <td>63</td>
      <td>89.0</td>
      <td>6.0</td>
      <td>5.0</td>
      <td>4.209524</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Electronics|Smartphones</td>
      <td>49</td>
      <td>15</td>
      <td>4</td>
      <td>68</td>
      <td>72.0</td>
      <td>22.0</td>
      <td>6.0</td>
      <td>4.100000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Electronics|In-Ear</td>
      <td>46</td>
      <td>3</td>
      <td>3</td>
      <td>52</td>
      <td>88.0</td>
      <td>6.0</td>
      <td>6.0</td>
      <td>3.898077</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Установка цвета
fig, ax1 = plt.subplots(figsize=(16, 6))
plt.title('Comparison of Rating and Count of Positive Comments by Category')
# Создание столбиковой диаграммы для positive comments

ax1.bar(merge_table['category'], merge_table['positive_comm_percent'], color='teal', alpha=0.6, label='Positive Comments')
ax1.set_ylabel('Percent of Positive Comments', color='teal', fontsize=14)
plt.ylim(0,120)
plt.xticks(rotation=90)
# Создание вторичной оси для отображения рейтинга
ax2 = ax1.twinx()
ax2.plot(merge_table['category'], merge_table['rating'], color='firebrick', marker='o', label='Rating')
ax2.set_ylabel('Average Rating', color='firebrick', fontsize=14)
plt.ylim(3, 4.7)
plt.grid(linestyle='--', alpha=0.6)


# Добавление легенды
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')


plt.show()

```


    
![png](output_42_0.png)
    



```python
amazon['discount_percentage'].dtype
```


```python
#Соединяем столбцы 'discount_percentage' и 'rating', чтобы сравнить их
discount_rating.reset_index(inplace=True)
discount_rating.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>category</th>
      <th>discount_percentage</th>
      <th>Positive</th>
      <th>Negative</th>
      <th>Neytral</th>
      <th>rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Electronics|ScreenProtectors</td>
      <td>66.857143</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>4.471429</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Electronics|DisposableBatteries</td>
      <td>14.285714</td>
      <td>4</td>
      <td>1</td>
      <td>2</td>
      <td>4.414286</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Computers&amp;Accessories|ExternalHardDisks</td>
      <td>27.000000</td>
      <td>4</td>
      <td>2</td>
      <td>0</td>
      <td>4.400000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Computers&amp;Accessories|GamingMice</td>
      <td>33.500000</td>
      <td>5</td>
      <td>1</td>
      <td>0</td>
      <td>4.383333</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Computers&amp;Accessories|MousePads</td>
      <td>61.250000</td>
      <td>8</td>
      <td>0</td>
      <td>0</td>
      <td>4.375000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Установка цвета
fig, ax1 = plt.subplots(figsize=(16, 6))
plt.title('Comparison of Rating and Percent of discount_percentage by Category')
# Создание столбиковой диаграммы для positive comments
ax1.bar(discount_rating['category'], discount_rating['discount_percentage'].sort_values(), color='g', alpha=0.4, label='Discount percentage')
ax1.set_ylabel('Percent of discount_percentage', color='g')
plt.xticks(rotation=90)

# Создание вторичной оси для отображения рейтинга
ax2 = ax1.twinx()
ax2.plot(discount_rating['category'], discount_rating['rating'], color='g',linewidth=4 , label='Rating')
ax2.set_ylabel('Average Rating', color='g')
ax2.set_xticks('')

# Добавление легенды
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')


plt.show()
```


    
![png](output_45_0.png)
    



```python

```
